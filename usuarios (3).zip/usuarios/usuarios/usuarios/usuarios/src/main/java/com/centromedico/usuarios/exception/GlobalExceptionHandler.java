package com.centromedico.usuarios.exception;


import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


//Restcontroller advice convierte las excepciones en respuestas JSON o XML
@RestControllerAdvice
public class GlobalExceptionHandler {
}
