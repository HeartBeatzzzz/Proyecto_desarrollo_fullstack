package com.centromedico.usuarios.service;


import com.centromedico.usuarios.dto.UsuarioRequestDTO;
import com.centromedico.usuarios.dto.UsuarioResponseDTO;
import com.centromedico.usuarios.model.Usuario;
import com.centromedico.usuarios.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;


    //Inicializa un objeto de tipo DTO al cual se le pueden setear datos
    private UsuarioResponseDTO mapToDTO (Usuario u){
        return new UsuarioResponseDTO(u.getId(), u.getNombreUsuario()
        , u.getFechaNacimiento(), u.getComunaUsuario(), u.getCiudadUsuario(),
          u.getTelefonoUsuario(), u.getEmailUsuario());
    }

    /*Se obtienen todos los datos mediante el findall,
    luego con stream permite transformarse en un flujo de datos
    A traves de map se le asigna el objeto DTO y luego la colleción se pasa a lista
    */
    public List <UsuarioResponseDTO> obtenerTodos(){
        return usuarioRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public Optional<UsuarioResponseDTO> obtenerPorId(Long id){
        return usuarioRepository.findById(id).map(this::mapToDTO);
    }

    //Llamada a los datos
    public UsuarioResponseDTO guardar (UsuarioRequestDTO dto){
        Usuario usuario = new Usuario(null, dto.getNombreUsuario(), dto.getFechaNacimiento(),
                dto.getComunaUsuario(), dto.getCiudadUsuario(), dto.getTelefonoUsuario(), dto.getEmailUsuario());
        return mapToDTO(usuarioRepository.save(usuario));
    }


    //Seteo mediante la id
    public Optional <UsuarioResponseDTO> actualizar (Long id, UsuarioRequestDTO dto){
        return usuarioRepository.findById(id).map(existente -> {
            existente.setNombreUsuario(dto.getNombreUsuario());
            existente.setFechaNacimiento(dto.getFechaNacimiento());
            existente.setComunaUsuario(dto.getComunaUsuario());
            existente.setCiudadUsuario(dto.getCiudadUsuario());
            existente.setTelefonoUsuario(dto.getTelefonoUsuario());
            existente.setEmailUsuario(dto.getTelefonoUsuario());
            return mapToDTO(usuarioRepository.save(existente));
        });
    }

    public void eliminar (Long id){usuarioRepository.deleteById(id);}


}
