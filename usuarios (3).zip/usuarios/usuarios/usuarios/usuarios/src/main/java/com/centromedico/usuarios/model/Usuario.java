package com.centromedico.usuarios.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "usuarios")
public class Usuario
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column (name = "RUT_USUARIO", nullable = false, length = 10)
    private String rutUsuario;

    @Column (name = "ID_CITA", nullable = false)
    private Long idCita;

    @Column(name = "NOMBRE_USUARIO", nullable = false, length = 100)
    private String nombreUsuario;

    @Column(name = "FECHA_NAC_USUARIO")
    private LocalDate fechaNacimiento;

    @ManyToOne //Unir las dos tablas mediante el id de la ciudad
    @JoinColumn(name = "ID_CIUDAD", nullable = false)
    private Ciudad ciudad;

    @Column(name = "TELEFONO_USUARIO", nullable = true, length = 20)
    private String telefonoUsuario;

    @Column(name = "EMAIL_USUARIO", nullable = false, length = 100)
    private String emailUsuario;
}
