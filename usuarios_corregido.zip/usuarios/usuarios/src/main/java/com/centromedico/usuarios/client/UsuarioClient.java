package com.centromedico.usuarios.client;

import com.centromedico.usuarios.dto.UsuarioResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "usuarios-service", url = "${usuario.service.url}")
public interface UsuarioClient {

    @GetMapping("/api/usuarios")
    List<UsuarioResponseDTO> obtenerTodos();

    @GetMapping("/api/usuarios/{id}")
    UsuarioResponseDTO obtenerPorId(@PathVariable("id") Long id);
}