CREATE TABLE CIUDAD(
    id_ciudad BIGINT AUTO_INCREMENT,
    nombre_ciudad Varchar(255) NOT NULL,
    comuna  Varchar(100) NOT NULL
    );