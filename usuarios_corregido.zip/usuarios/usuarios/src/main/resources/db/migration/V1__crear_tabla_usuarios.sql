CREATE TABLE USUARIO(
    id_usuario      BIGINT AUTO_INCREMENT,
    rut_usuario     VARCHAR(10)  NOT NULL,
    id_cita         BIGINT       NULL,
    nombre_usuario  VARCHAR(100) NOT NULL,
    fecha_nac_usuario DATE,
    id_ciudad       BIGINT       NOT NULL,
    telefono_usuario VARCHAR(20),
    email_usuario   VARCHAR(100) NOT NULL,
    CONSTRAINT pk_id_usuario PRIMARY KEY (id_usuario)
);
