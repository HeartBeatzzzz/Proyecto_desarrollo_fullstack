package com.centromedico.usuarios.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "usuarios")
public class Usuario
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "NOMBRE_USUARIO", nullable = false, length = 100)
    private String nombreUsuario;

    @Column(name = "FECHA_NAC_USUARIO")
    private LocalDate fechaNacimiento;

    @Column(name = "COMUNA_USUARIO", nullable = false, length = 100)
    private String comunaUsuario;

    @Column(name = "CIUDAD_USUARIO", nullable = false, length = 100)
    private String ciudadUsuario;

    @Column(name = "TELEFONO_USUARIO", nullable = false, length = 20)
    private String telefonoUsuario;

    @Column(name = "EMAIL_USUARIO", nullable = false, length = 100)
    private String emailUsuario;
}
