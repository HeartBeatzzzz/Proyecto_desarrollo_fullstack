package com.centromedico.usuarios.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioResponseDTO {

    private Long idUsuario;
    private String nombreUsuario;
    private LocalDate fechaNacimiento;
    private String comunaUsuario;
    private String ciudadUsuario;
    private String telefonoUsuario;
    private String emailUsuario;
}
