package com.centromedico.usuarios.service;


import com.centromedico.usuarios.dto.UsuarioRequestDTO;
import com.centromedico.usuarios.dto.UsuarioResponseDTO;
import com.centromedico.usuarios.model.Usuario;
import com.centromedico.usuarios.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    private UsuarioResponseDTO mapToDTO (Usuario u){
        return new UsuarioResponseDTO(u.getId(), u.getNombreUsuario()
        , u.getFechaNacimiento(), u.getComunaUsuario(), u.getCiudadUsuario(),
          u.getTelefonoUsuario(), u.getEmailUsuario());
    }

    public List <UsuarioResponseDTO> obtenerTodos(){
        return usuarioRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public Optional<UsuarioResponseDTO> obtenerPorId(Long id){
        return usuarioRepository.findById(id).map(this::mapToDTO);
    }

    public UsuarioResponseDTO guardar (UsuarioRequestDTO dto){
        Usuario usuario = new Usuario(null, dto.getNombreUsuario(), dto.getFechaNacimiento(),
                dto.getComunaUsuario(), dto.getCiudadUsuario(), dto.getTelefonoUsuario(), dto.getEmailUsuario());
        return mapToDTO(usuarioRepository.save(usuario));
    }

    public Optional <UsuarioResponseDTO> actualizar (Long id, UsuarioRequestDTO dto){
        return usuarioRepository.findById(id).map(existente -> {
            existente.setNombreUsuario(dto.getNombreUsuario());
            existente.setFechaNacimiento(dto.getFechaNacimiento());
            existente.setComunaUsuario(dto.getComunaUsuario());
            existente.setCiudadUsuario(dto.getCiudadUsuario());
            existente.setTelefonoUsuario(dto.getTelefonoUsuario());
            existente.setEmailUsuario(dto.getTelefonoUsuario());
            return mapToDTO(usuarioRepository.save(existente));
        });
    }

    public void eliminar (Long id){usuarioRepository.deleteById(id);}


}
