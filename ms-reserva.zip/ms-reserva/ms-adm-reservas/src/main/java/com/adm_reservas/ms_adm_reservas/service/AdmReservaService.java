package com.adm_reservas.ms_adm_reservas.service;

import com.adm_reservas.ms_adm_reservas.client.AdmReservasClient;
import com.adm_reservas.ms_adm_reservas.dto.AdmReservasResponseDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class AdmReservaService {

    private final AdmReservasClient admReservasClient;

    public List<AdmReservasResponseDTO> listarTodas(){
        log.info("listando todas las reservas");
        return admReservasClient.listarTodas();
    }

    public List<AdmReservasResponseDTO> obtenerPorPaciente(String rutUsuario){
        log.info("Consultando reservas del paciente");
        return admReservasClient.obtenerPorPaciente(rutUsuario);

    }

    public List<AdmReservasResponseDTO> obtenerPorEmpleado(String rutEmpleado){
        log.info("consultando reservas del empleado");
        return admReservasClient.obtenerPorEmpleado(rutEmpleado);

    }

    public List<AdmReservasResponseDTO> obtenerPorFecha(LocalDate fechaReserva){
        log.info("Consultando reservas por fecha");
        return admReservasClient.obtenerPorFecha(fechaReserva);
    }
    public List<AdmReservasResponseDTO> obtenerPorEstado(String estadoReserva){
        log.info("Cancelando reserva desde administracion");
        return admReservasClient.obtenerPorEstado(estadoReserva);
    }
    public AdmReservasResponseDTO cancelarReserva(String rutUsuario, LocalDate fechaReserva){
        log.info("Cancelando reserva desde administracion");
        return admReservasClient.cancelarReserva(rutUsuario,fechaReserva);
    }
}
