package com.adm_reservas.ms_adm_reservas.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdmReservasResponseDTO {

    private Long id;
    private String tipoReserva;
    private LocalDate fechaReserva;
    private LocalTime horaReserva;
    private String estadoReserva;
    private String rutUsuario;
    private String rutEmpleado;
    private String mensaje;
}
