package com.adm_reservas.ms_adm_reservas.client;

import com.adm_reservas.ms_adm_reservas.dto.AdmReservasResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import java.time.LocalDate;
import java.util.List;

@FeignClient(name = "adm-reservas", url = "${reservas.service.url}")
public interface AdmReservasClient {

    @GetMapping("/api/citas")
    List<AdmReservasResponseDTO> listarTodas();

    @GetMapping("/api/citas/usuario/{rutUsuario}")
    List<AdmReservasResponseDTO> obtenerPorPaciente(@PathVariable String rutUsuario);

    @GetMapping("/api/citas/empleado/{rutEmpleado}")
    List<AdmReservasResponseDTO> obtenerPorEmpleado(@PathVariable String rutEmpleado);

    @GetMapping("/api/citas/fecha/{fechaReserva}")
    List<AdmReservasResponseDTO> obtenerPorFecha(@PathVariable LocalDate fechaReserva);

    @GetMapping("/api/citas/estado/{estadoReserva}")
    List<AdmReservasResponseDTO> obtenerPorEstado(@PathVariable String estadoReserva);

    @PutMapping("/api/citas/usuario/{rutUsuario}/fecha/{fechaReserva}/cancelar")
    AdmReservasResponseDTO cancelarReserva(
            @PathVariable String rutUsuario,
            @PathVariable LocalDate fechaReserva
    );




}
