package com.adm_reservas.ms_adm_reservas.controller;

import com.adm_reservas.ms_adm_reservas.dto.AdmReservasResponseDTO;
import com.adm_reservas.ms_adm_reservas.service.AdmReservaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/admin-reservas")
public class AdmReservasController {

    private final AdmReservaService admReservaService;

    @GetMapping
    public List<AdmReservasResponseDTO> listarTodas(){
        return admReservaService.listarTodas();
    }

    @GetMapping("/paciente/{rutUsuario}")
    public List<AdmReservasResponseDTO> obtenerPorPaciente(@PathVariable String rutUsuario){
        return admReservaService.obtenerPorPaciente(rutUsuario);

    }

    @GetMapping("/medico/{rutEmpleado}")
    public List<AdmReservasResponseDTO> obtenerPorEmpleado(@PathVariable String rutEmpleado){
        return admReservaService.obtenerPorEmpleado(rutEmpleado);
    }

    @GetMapping("/fecha/{fechaReserva}")
    public List<AdmReservasResponseDTO> obtenerPorFecha(@PathVariable LocalDate fechaReserva){
        return admReservaService.obtenerPorFecha(fechaReserva);
    }

    @GetMapping("/estado/{estadoReserva}")
    public List<AdmReservasResponseDTO> obtenerPorEstado(@PathVariable String estadoReserva){
        return admReservaService.obtenerPorEstado(estadoReserva);

    }

    @PutMapping("/paciente/{rutUsuario}/fecha/{fechaReserva}/cancelar")
    public AdmReservasResponseDTO cancelarReserva(@PathVariable String rutUsuario,
                                                  @PathVariable LocalDate fechaReserva){
        return admReservaService.cancelarReserva(rutUsuario,fechaReserva);
    }

}
