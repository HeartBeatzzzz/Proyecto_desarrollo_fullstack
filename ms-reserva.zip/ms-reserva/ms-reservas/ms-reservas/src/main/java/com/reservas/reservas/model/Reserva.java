package com.reservas.reservas.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDate;
import java.time.LocalTime;
@Entity
@Data
@Table(name = "cita")
@NoArgsConstructor
@AllArgsConstructor

public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "tipo_cita", nullable = false, length = 100)
    private String tipoReserva;

    @Column(name = "fecha_cita", nullable = false)
    private LocalDate fechaReserva;

    @Column(name = "hora_cita", nullable = false)
    private LocalTime horaReserva;

    @Column(name = "estado_cita", nullable = false, length = 50)
    private String estadoReserva;

    @Column(name = "rut_usuario", nullable = false, length = 10)
    private String rutUsuario;

    @Column(name = "rut_emp", nullable = false, length = 10)
    private String rutEmpleado;

}
