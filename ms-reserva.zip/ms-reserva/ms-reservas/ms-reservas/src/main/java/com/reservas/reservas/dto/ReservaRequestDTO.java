package com.reservas.reservas.dto;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class ReservaRequestDTO {

    @NotBlank(message = "El tipo de reserva no puede estar vacio")
    @Size(max = 100)
    private String tipoReserva;

    @NotNull(message = "La fecha es obligatoria")
    @FutureOrPresent(message = "La fecha no puede ser pasada")

    private LocalDate fechaReserva;
    @NotNull(message = "La hora es obligatoria")

    private LocalTime horaReserva;
    @NotBlank(message = "El RUT del usuario es obligatorio")
    private String rutUsuario;

    @NotBlank(message = "El RUT del empleado es obligatorio")
    private String rutEmpleado;
}
