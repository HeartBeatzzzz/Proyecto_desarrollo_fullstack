package com.reservas.reservas.repository;

import com.reservas.reservas.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
    List<Reserva> findByRutUsuario(String rutUsua);

    List<Reserva> findByRutEmpleado(String rutEmp);

    List<Reserva> findByEstadoReserva(String estadoReserva);

    List<Reserva> findByFechaReserva(LocalDate fechaCita);

    Optional<Reserva> findByRutUsuarioAndFechaReserva(String rutUsua, LocalDate fechaReserva);
}
