package com.reservas.reservas.controller;

import com.reservas.reservas.dto.ReservaRequestDTO;
import com.reservas.reservas.dto.ReservaResponseDTO;
import com.reservas.reservas.service.ReservaService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/citas")
@RequiredArgsConstructor
public class ReservaController {
    private final ReservaService reservaService;

    @GetMapping
    public List<ReservaResponseDTO> listarReservas(){
        return reservaService.listarReservas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReservaResponseDTO> obtenerPorId(@PathVariable Long id){

        return reservaService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/usuario/{rut}")
    public List<ReservaResponseDTO> obtenerPorRutUsuario(@PathVariable String rut){
        return reservaService.buscarPorRutUsuario(rut);

    }
    @GetMapping("/empleado/{rut}")
    public List<ReservaResponseDTO> obtenerPorRutEmpleado(@PathVariable String rut){
        return reservaService.buscarPorRutEmpleado(rut);

    }
    @GetMapping("/estado/{estadoReserva}")
    public List<ReservaResponseDTO> obtenerPorEstadoReserva(@PathVariable String estadoReserva){

        return reservaService.buscarPorEstadoReserva(estadoReserva);
    }
    @GetMapping("/fecha/{fechaReserva}")
    public List<ReservaResponseDTO> obtenerPorFechaReserva(@PathVariable LocalDate fechaReserva){
        return reservaService.buscarPorFechaReserva(fechaReserva);
    }

    @PostMapping
    public ResponseEntity<ReservaResponseDTO> crearReserva(@Valid @RequestBody ReservaRequestDTO dto){
        return ResponseEntity.status(201).body(reservaService.guardar(dto));
    }

    @PutMapping("/{idCita}/cancelar")
    public ResponseEntity<ReservaResponseDTO> cancelarPorId(@PathVariable Long idCita){
        return reservaService.cancelarPorId(idCita)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());

    }
}
