package com.reservas.reservas.service;

import com.reservas.reservas.dto.ReservaRequestDTO;
import com.reservas.reservas.dto.ReservaResponseDTO;
import com.reservas.reservas.model.Reserva;
import com.reservas.reservas.repository.ReservaRepository;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReservaService {


    private final ReservaRepository reservaRepository;

    private ReservaResponseDTO mapToDTO(Reserva reserva){
        return new ReservaResponseDTO(
                reserva.getId(),
                reserva.getTipoReserva(),
                reserva.getFechaReserva(),
                reserva.getHoraReserva(),
                reserva.getEstadoReserva(),
                reserva.getRutUsuario(),
                reserva.getRutEmpleado(),
                "Ok"
        );


    }

    public ReservaResponseDTO guardar(ReservaRequestDTO dto){
        Reserva reserva = new Reserva();
        reserva.setTipoReserva(dto.getTipoReserva());
        reserva.setFechaReserva(dto.getFechaReserva());
        reserva.setHoraReserva(dto.getHoraReserva());
        reserva.setRutUsuario(dto.getRutUsuario());
        reserva.setRutEmpleado(dto.getRutEmpleado());
        reserva.setEstadoReserva("RESERVADA");
        log.info(">>>>> Reserva creada con exito <<<<<");

        return mapToDTO(reservaRepository.save(reserva));

    }




public List<ReservaResponseDTO> listarReservas(){
        return reservaRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

public List<ReservaResponseDTO> buscarPorRutUsuario(String rutUsua){
        return reservaRepository
                .findByRutUsuario(rutUsua)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());

    }

public List<ReservaResponseDTO> buscarPorRutEmpleado(String rutEmp){
        return reservaRepository.findByRutEmpleado(rutEmp)
                .stream()
                .map(this::mapToDTO)
                .collect((Collectors.toList()));
}

public List<ReservaResponseDTO> buscarPorEstadoReserva(String estadoReserva){
        return reservaRepository.findByEstadoReserva(estadoReserva)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());

}

public List<ReservaResponseDTO> buscarPorFechaReserva(LocalDate fechaReserva){
        return reservaRepository.findByFechaReserva(fechaReserva)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
}

public Optional<ReservaResponseDTO> obtenerPorId(Long id){

        return reservaRepository
                .findById(id)
                .map(this::mapToDTO);
    }
    @Transactional
    public Optional<ReservaResponseDTO> cancelarPorId( Long idCita){
        return reservaRepository.findById(idCita)
                .map(reserva -> {reserva.setEstadoReserva("CANCELADA");
                log.info("Cita cancelada");
                return mapToDTO(reservaRepository.save(reserva));
                });

    }




}
