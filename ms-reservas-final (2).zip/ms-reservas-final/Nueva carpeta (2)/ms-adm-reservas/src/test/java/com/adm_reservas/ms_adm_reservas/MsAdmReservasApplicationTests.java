package com.adm_reservas.ms_adm_reservas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAdmReservasApplicationTests {

	@Test
	void contextLoads() {
	}

}
