package com.adm_reservas.ms_adm_reservas.controller;

import com.adm_reservas.ms_adm_reservas.dto.AdmReservasResponseDTO;
import com.adm_reservas.ms_adm_reservas.service.AdmReservaService;
import lombok.RequiredArgsConstructor;
import org.hibernate.type.descriptor.java.LongJavaType;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/admin-reservas")
public class AdmReservasController {

    private final AdmReservaService admReservaService;

    @GetMapping
    public List<AdmReservasResponseDTO> listarTodas(){
        return admReservaService.listarTodas();
    }

    @GetMapping("/paciente/{idUsuario}")
    public List<AdmReservasResponseDTO> obtenerPorPaciente(@PathVariable Long idUsuario){
        return admReservaService.obtenerPorPaciente(idUsuario);

    }

    @GetMapping("/medico/{idEmp}")
    public List<AdmReservasResponseDTO> obtenerPorEmpleado(@PathVariable Long idEmp){
        return admReservaService.obtenerPorEmpleado(idEmp);
    }


    @GetMapping("/estado/{disponibilidadCita}")
    public List<AdmReservasResponseDTO> obtenerPorDisponibilidad(@PathVariable String disponibilidadCita){
        return admReservaService.obtenerPordisponibilidad(disponibilidadCita);


    }

    @PutMapping("/{idCita}/cancelar")
    public AdmReservasResponseDTO cancelarReserva(@PathVariable Long idCita){
        return admReservaService.cancelarReserva(idCita);
    }

}
