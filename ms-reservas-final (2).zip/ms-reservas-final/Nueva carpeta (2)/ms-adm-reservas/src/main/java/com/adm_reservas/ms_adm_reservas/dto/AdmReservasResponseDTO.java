package com.adm_reservas.ms_adm_reservas.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdmReservasResponseDTO {

    private Long idCita;
    private String tipoCita;
    private LocalDate fechaCita;

    private String idEmp;
    private String disponibilidadCita;
}
