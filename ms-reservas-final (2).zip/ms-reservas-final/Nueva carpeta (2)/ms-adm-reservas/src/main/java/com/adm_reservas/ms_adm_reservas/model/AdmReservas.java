package com.adm_reservas.ms_adm_reservas.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.AnyDiscriminatorImplicitValues;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "adm_reservas")

public class AdmReservas {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reserva")
    private Long id;


    @Column(nullable = false,
            length = 50 ,
            name = "rut_emp")
    private String rutEmp;


    @Column(nullable = false,
            length = 100,
            name = "especialidad")
    private String especialidad;


    @Column(nullable = false,
            name = "fecha_reserva")
    private LocalDate fechaReserva;


    @Column(nullable = false,
            name = "hora_inicio")
    private LocalTime horaInicio;


    @Column(nullable = false,
            name = "hora_termino")
    private LocalTime horaTermino;


    @Column(nullable = false,
            name = "estadoReserva")
    private String estadoReserva;


}
