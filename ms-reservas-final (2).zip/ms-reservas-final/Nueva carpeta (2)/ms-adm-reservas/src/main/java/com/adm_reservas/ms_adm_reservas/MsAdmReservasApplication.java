package com.adm_reservas.ms_adm_reservas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class MsAdmReservasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAdmReservasApplication.class, args);
	}

}
