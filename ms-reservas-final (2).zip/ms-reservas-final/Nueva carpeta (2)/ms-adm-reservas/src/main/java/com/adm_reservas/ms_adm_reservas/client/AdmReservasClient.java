package com.adm_reservas.ms_adm_reservas.client;

import com.adm_reservas.ms_adm_reservas.dto.AdmReservasResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import java.time.LocalDate;
import java.util.List;

@FeignClient(name = "adm-reservas", url = "${reservas.service.url}")
public interface AdmReservasClient {

    @GetMapping("/api/citas")
    List<AdmReservasResponseDTO> listarTodas();

    @GetMapping("/api/citas/usuario/{idUsuario}")
    List<AdmReservasResponseDTO> obtenerPorPaciente(@PathVariable Long idUsuario);

    @GetMapping("/api/citas/empleado/{idEmp}")
    List<AdmReservasResponseDTO> obtenerPorEmpleado(@PathVariable Long idEmp);


    @GetMapping("/api/citas/disponibilidad/{disponibilidadCita}")
    List<AdmReservasResponseDTO> obtenerPorDisponibilidad(
            @PathVariable String disponibilidadCita
    );

    @PutMapping("/api/citas/{idCita}/cancelar")
    AdmReservasResponseDTO cancelarReserva(
            @PathVariable Long idCita
    );




}
