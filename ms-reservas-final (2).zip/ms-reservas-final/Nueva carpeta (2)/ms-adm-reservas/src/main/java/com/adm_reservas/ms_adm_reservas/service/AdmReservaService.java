package com.adm_reservas.ms_adm_reservas.service;

import com.adm_reservas.ms_adm_reservas.client.AdmReservasClient;
import com.adm_reservas.ms_adm_reservas.dto.AdmReservasResponseDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class AdmReservaService {

    private final AdmReservasClient admReservasClient;

    public List<AdmReservasResponseDTO> listarTodas(){
        log.info("listando todas las reservas");
        return admReservasClient.listarTodas();
    }

    public List<AdmReservasResponseDTO> obtenerPorPaciente(Long idUsuario){
        log.info("Consultando reservas del paciente");
        return admReservasClient.obtenerPorPaciente(idUsuario);

    }

    public List<AdmReservasResponseDTO> obtenerPorEmpleado(Long idEmp){
        log.info("consultando reservas del empleado");
        return admReservasClient.obtenerPorEmpleado(idEmp);

    }

    public List<AdmReservasResponseDTO> obtenerPorDisponibilidad(String disponibilidadCita){

        return admReservasClient.obtenerPorDisponibilidad(disponibilidadCita);
    }
    public AdmReservasResponseDTO cancelarReserva(Long idCita){
        log.info("Cancelando reserva desde administracion");
        return admReservasClient.cancelarReserva(idCita);
    }
}
