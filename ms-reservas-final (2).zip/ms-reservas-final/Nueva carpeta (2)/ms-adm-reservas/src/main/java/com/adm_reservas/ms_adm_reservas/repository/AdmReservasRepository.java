package com.adm_reservas.ms_adm_reservas.repository;

import com.adm_reservas.ms_adm_reservas.model.AdmReservas;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AdmReservasRepository extends JpaRepository<AdmReservas, Long> {

    public List<AdmReservas> findByRutEmpleado(String rutEmp);
}
