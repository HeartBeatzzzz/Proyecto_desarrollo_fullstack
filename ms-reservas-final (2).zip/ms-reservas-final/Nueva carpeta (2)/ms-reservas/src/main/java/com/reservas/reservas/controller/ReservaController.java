package com.reservas.reservas.controller;

import com.reservas.reservas.dto.ReservaRequestDTO;
import com.reservas.reservas.dto.ReservaResponseDTO;
import com.reservas.reservas.service.ReservaService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/citas")
@RequiredArgsConstructor
public class ReservaController {
    private final ReservaService reservaService;

    @GetMapping
    public List<ReservaResponseDTO> listarReservas(){
        return reservaService.listarReservas();
    }

    @GetMapping("/{idCita}")
    public ResponseEntity<ReservaResponseDTO> obtenerPorId(@PathVariable Long idCita){

        return reservaService.buscarPorId(idCita)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<ReservaResponseDTO> obtenerPorUsuario(@PathVariable Long idUsuario){
        return reservaService.buscarPorUsuario(idUsuario);

    }
    @GetMapping("/empleado/{idEmp}")
    public List<ReservaResponseDTO> obtenerPorRutEmpleado(@PathVariable Long idEmp){
        return reservaService.buscarPorEmpleado(idEmp);

    }
    @GetMapping("/estado/{disponibilidadCita}")
    public List<ReservaResponseDTO> obtenerPorEstadoReserva(@PathVariable String disponibilidadCita){

        return reservaService.buscarPorDisponibilidad(disponibilidadCita);
    }

    @PostMapping
    public ResponseEntity<ReservaResponseDTO> crearReserva(@Valid @RequestBody ReservaRequestDTO dto){
        return ResponseEntity.status(201).body(reservaService.guardar(dto));
    }

    @PutMapping("/{idCita}/cancelar")
    public ResponseEntity<ReservaResponseDTO> cancelarPorId(@PathVariable Long idCita){
        return reservaService.cancelarPorId(idCita)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());

    }
}
