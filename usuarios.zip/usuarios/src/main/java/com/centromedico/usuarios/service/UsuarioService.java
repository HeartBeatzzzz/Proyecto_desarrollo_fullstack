package com.centromedico.usuarios.service;

import com.centromedico.usuarios.dto.UsuarioRequestDTO;
import com.centromedico.usuarios.dto.UsuarioResponseDTO;
import com.centromedico.usuarios.model.Ciudad;
import com.centromedico.usuarios.model.Usuario;
import com.centromedico.usuarios.repository.CiudadRepository;
import com.centromedico.usuarios.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final CiudadRepository ciudadRepository;

    // Corregido: u.getIdCiudad() no existe; la entidad tiene Ciudad ciudad.
    // Se accede al ID mediante u.getCiudad().getId().
    private UsuarioResponseDTO mapToDTO(Usuario u) {
        return new UsuarioResponseDTO(
                u.getId(),
                u.getRutUsuario(),
                u.getIdCita(),
                u.getNombreUsuario(),
                u.getFechaNacimiento(),
                u.getCiudad().getId(),
                u.getTelefonoUsuario(),
                u.getEmailUsuario()
        );
    }

    public List<UsuarioResponseDTO> obtenerTodos() {
        return usuarioRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public Optional<UsuarioResponseDTO> obtenerPorId(Long id) {
        return usuarioRepository.findById(id).map(this::mapToDTO);
    }

    // Corregido: el constructor de Usuario espera Ciudad ciudad, no Long idCiudad.
    public UsuarioResponseDTO guardar(UsuarioRequestDTO dto) {
        Ciudad ciudad = ciudadRepository.findById(dto.getIdCiudad())
                .orElseThrow(() -> new RuntimeException(
                        "Ciudad no encontrada con ID: " + dto.getIdCiudad()));

        Usuario usuario = new Usuario(
                null,
                dto.getRutUsuario(),
                null,
                dto.getNombreUsuario(),
                dto.getFechaNacimiento(),
                ciudad,
                dto.getTelefonoUsuario(),
                dto.getEmailUsuario()
        );
        return mapToDTO(usuarioRepository.save(usuario));
    }

    // Corregido: existente.setIdCiudad() no existe; se usa existente.setCiudad(ciudad).
    public Optional<UsuarioResponseDTO> actualizar(Long id, UsuarioRequestDTO dto) {
        return usuarioRepository.findById(id).map(existente -> {
            Ciudad ciudad = ciudadRepository.findById(dto.getIdCiudad())
                    .orElseThrow(() -> new RuntimeException(
                            "Ciudad no encontrada con ID: " + dto.getIdCiudad()));

            existente.setRutUsuario(dto.getRutUsuario());
            existente.setNombreUsuario(dto.getNombreUsuario());
            existente.setFechaNacimiento(dto.getFechaNacimiento());
            existente.setCiudad(ciudad);
            existente.setTelefonoUsuario(dto.getTelefonoUsuario());
            existente.setEmailUsuario(dto.getEmailUsuario());
            return mapToDTO(usuarioRepository.save(existente));
        });
    }

    public void eliminar(Long id) {
        usuarioRepository.deleteById(id);
    }
}
